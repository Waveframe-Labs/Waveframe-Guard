# ---
# title: "Waveframe Guard Quickstart Regression Test"
# filetype: "python"
# type: "test"
# domain: "guard-sdk"
# version: "0.18.0"
# status: "Active"
# author:
#   name: "Waveframe Labs"
# license: "Apache-2.0"
# ai_assisted: "partial"
# ---

from __future__ import annotations

from examples import quickstart_guard


def test_quickstart_guard_blocks_before_execution(capsys):
    quickstart_guard.main()

    output = capsys.readouterr().out

    assert "executed=False" in output
    assert "decision=blocked" in output
    assert "transfer executed" not in output
