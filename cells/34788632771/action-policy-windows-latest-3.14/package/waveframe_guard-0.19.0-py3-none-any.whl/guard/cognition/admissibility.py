from __future__ import annotations

from typing import Any


def assess_admissibility(
    *,
    compiled_authority: dict[str, Any],
    execution_request: dict[str, Any],
    actor_identity: dict[str, Any],
    continuity_state: dict[str, Any] | None = None,
    replay_posture: dict[str, Any] | None = None,
    evidence_posture: dict[str, Any] | None = None,
) -> dict[str, Any]:
    continuity_state = continuity_state or {}
    replay_posture = replay_posture or {}
    evidence_posture = evidence_posture or {}
    continuation_status = evidence_posture.get("continuation_status") or {}

    violated_constraints = []
    required_evidence = []
    continuity_requirements = []
    replay_obligations = []

    if compiled_authority.get("schema_version") == "compiled_authority_contract.v3":
        violated_constraints.extend(_action_constraints(compiled_authority, execution_request, actor_identity))
    else:
        if execution_request.get("action") == "create":
            violated_constraints.append({"constraint": "action_grant", "rationale": "legacy authority cannot authorize creation"})
        violated_constraints.extend(_target_scope_constraints(compiled_authority, execution_request))
        violated_constraints.extend(_role_constraints(compiled_authority, actor_identity))
    required_evidence.extend(
        _approval_evidence_requirements(
            compiled_authority=compiled_authority,
            execution_request=execution_request,
            evidence_posture=evidence_posture,
        )
    )
    violated_constraints.extend(
        _separation_of_duties_constraints(
            compiled_authority=compiled_authority,
            actor_identity=actor_identity,
            evidence_posture=evidence_posture,
        )
    )
    continuity_requirements.extend(_continuity_requirements(continuity_state))
    replay_obligations.extend(_replay_obligations(replay_posture))
    violated_constraints.extend(_continuation_constraints(continuation_status))
    if not continuity_requirements:
        continuity_requirements.extend(_continuation_requirements(continuation_status))
    if not replay_obligations:
        replay_obligations.extend(_continuation_replay_obligations(continuation_status))

    if violated_constraints or required_evidence:
        status = "blocked"
        rationale = _blocked_rationale(violated_constraints, required_evidence)
    elif continuity_requirements or replay_obligations:
        status = "escalated"
        rationale = "runtime posture requires revalidation or replay before execution"
    else:
        status = "admissible"
        rationale = "execution is admissible against compiled authority"

    enforcement_consequences = _enforcement_consequences(
        status=status,
        violated_constraints=violated_constraints,
        required_evidence=required_evidence,
        continuity_requirements=continuity_requirements,
        replay_obligations=replay_obligations,
    )

    return {
        "status": status,
        "rationale": rationale,
        "violated_constraints": violated_constraints,
        "required_evidence": required_evidence,
        "replay_obligations": replay_obligations,
        "continuity_requirements": continuity_requirements,
        "enforcement_consequences": enforcement_consequences,
        "continuation_status": continuation_status,
    }


def _action_constraints(authority, request, actor):
    action = request.get("action")
    block = authority["action_requirements"].get(action)
    if block is None:
        return [{"constraint": "action_grant", "action": action,
                 "rationale": "selected action has no explicit grant"}]
    violations = []
    if block["required_role"] is not None and actor.get("role") != block["required_role"]:
        violations.append({"constraint": "required_role", "action": action,
                           "required_role": block["required_role"], "observed_role": actor.get("role"),
                           "rationale": "actor role is not authorized for this action"})
    target = request.get("target")
    if not isinstance(target, str) or not target:
        violations.append({"constraint": "execution_target", "action": action,
                           "rationale": "action requires a repository target"})
    elif any(_target_rule_matches(rule, target) for rule in block["deny"]):
        violations.append({"constraint": "target_scope_deny", "action": action,
                           "rationale": "execution target is denied for this action"})
    elif not any(_target_rule_matches(rule, target) for rule in block["allow"]):
        violations.append({"constraint": "target_scope_allow", "action": action,
                           "rationale": "selected action has no matching path allow"})
    return violations


def _target_scope_constraints(
    authority: dict[str, Any], execution_request: dict[str, Any]
) -> list[dict[str, Any]]:
    if "target_requirements" not in authority:
        return []

    requirements = authority["target_requirements"]
    if not isinstance(requirements, dict):
        return [_target_scope_violation("target_requirements")]

    if set(requirements) != {"allow", "deny"}:
        return [_target_scope_violation("target_requirements")]

    allow_rules = requirements["allow"]
    deny_rules = requirements["deny"]
    if not isinstance(allow_rules, list) or not isinstance(deny_rules, list):
        return [_target_scope_violation("target_requirements")]
    if not allow_rules and not deny_rules:
        return [_target_scope_violation("target_requirements")]
    if not all(_is_target_rule(rule) for rule in [*allow_rules, *deny_rules]):
        return [_target_scope_violation("target_requirements")]

    target = execution_request.get("target")
    if not isinstance(target, str) or not target.strip():
        return [
            {
                "constraint": "execution_target",
                "rationale": "execution target is required for target-scoped authority",
            }
        ]

    if any(_target_rule_matches(rule, target) for rule in deny_rules):
        return [
            {
                "constraint": "target_scope_deny",
                "rationale": "execution target is denied by compiled target scope",
            }
        ]
    if allow_rules and not any(_target_rule_matches(rule, target) for rule in allow_rules):
        return [
            {
                "constraint": "target_scope_allow",
                "rationale": "execution target is outside the allowed target scope",
            }
        ]
    return []


def _target_scope_violation(constraint: str) -> dict[str, Any]:
    return {
        "constraint": constraint,
        "rationale": "compiled target scope is invalid and cannot authorize execution",
    }


def _is_target_rule(rule: Any) -> bool:
    return (
        isinstance(rule, dict)
        and set(rule) == {"match", "value"}
        and isinstance(rule["match"], str)
        and rule["match"] in {"exact", "prefix"}
        and isinstance(rule["value"], str)
        and bool(rule["value"].strip())
    )


def _target_rule_matches(rule: dict[str, str], target: str) -> bool:
    if rule["match"] == "exact":
        return target == rule["value"]
    return target.startswith(rule["value"])


def _role_constraints(authority: dict[str, Any], actor: dict[str, Any]) -> list[dict[str, Any]]:
    required_roles = authority.get("authority_requirements", {}).get("required_roles") or []
    if not required_roles:
        return []
    if actor.get("role") in required_roles:
        return []
    return [
        {
            "constraint": "required_role",
            "required_roles": list(required_roles),
            "observed_role": actor.get("role"),
            "rationale": "actor role is not authorized by compiled authority",
        }
    ]


def _approval_evidence_requirements(
    *,
    compiled_authority: dict[str, Any],
    execution_request: dict[str, Any],
    evidence_posture: dict[str, Any],
) -> list[dict[str, Any]]:
    requirements = _approval_requirements(compiled_authority)
    approvals = evidence_posture.get("approvals") or []
    missing = []
    amount = _execution_amount(execution_request)
    for requirement in requirements:
        if not _condition_applies(requirement.get("condition"), amount):
            continue
        role = requirement.get("role")
        if not _approval_for_role(approvals, role):
            missing.append(
                {
                    "evidence": "approval",
                    "role": role,
                    "condition": requirement.get("condition"),
                    "rationale": "required approval evidence is missing",
                }
            )
    return missing


def _separation_of_duties_constraints(
    *,
    compiled_authority: dict[str, Any],
    actor_identity: dict[str, Any],
    evidence_posture: dict[str, Any],
) -> list[dict[str, Any]]:
    if not _separation_of_duties_enabled(compiled_authority):
        return []
    actor_id = actor_identity.get("id")
    approvals = evidence_posture.get("approvals") or []
    for approval in approvals:
        if approval.get("approved_by") == actor_id:
            return [
                {
                    "constraint": "separation_of_duties",
                    "actor_id": actor_id,
                    "approval_role": approval.get("role"),
                    "rationale": "actor cannot approve their own execution request",
                }
            ]
    return []


def _approval_requirements(authority: dict[str, Any]) -> list[dict[str, Any]]:
    approval_requirements = authority.get("approval_requirements", {})
    required = approval_requirements.get("required") or []
    thresholds = approval_requirements.get("thresholds") or []
    normalized_thresholds = []
    for threshold in thresholds:
        if not isinstance(threshold, dict):
            continue
        role = threshold.get("role") or threshold.get("requires_role")
        normalized_thresholds.append(
            {
                "role": role,
                "condition": {
                    "field": threshold.get("field"),
                    "operator": threshold.get("operator"),
                    "value": threshold.get("value"),
                },
            }
        )
    return [*required, *normalized_thresholds]


def _separation_of_duties_enabled(authority: dict[str, Any]) -> bool:
    invariants = authority.get("invariants", {})
    if isinstance(invariants, dict):
        separation_of_duties = invariants.get("separation_of_duties")
        return separation_of_duties is True or (
            isinstance(separation_of_duties, list) and bool(separation_of_duties)
        )
    return False


def _continuity_requirements(continuity_state: dict[str, Any]) -> list[dict[str, Any]]:
    requirements = list(continuity_state.get("requirements", []))
    if continuity_state.get("requires_revalidation") is True:
        requirements.append(
            {
                "requirement": "revalidation",
                "signals": list(continuity_state.get("signals", [])),
                "rationale": "continuity state requires runtime revalidation",
            }
        )
    return requirements


def _replay_obligations(replay_posture: dict[str, Any]) -> list[dict[str, Any]]:
    obligations = list(replay_posture.get("obligations", []))
    if replay_posture.get("required") is True and not obligations:
        obligations.append(
            {
                "obligation": "replay",
                "rationale": "execution must be linked to replay before enforcement",
            }
        )
    return obligations


def _continuation_constraints(continuation_status: dict[str, Any]) -> list[dict[str, Any]]:
    status = continuation_status.get("status")
    if status not in {"invalidated", "expired"}:
        return []
    return [
        {
            "constraint": "continuation_validity",
            "continuation_status": status,
            "dependency_failures": continuation_status.get("dependency_failures", []),
            "rationale": "continuation invalidated by runtime dependency state"
            if status == "invalidated"
            else "continuation expired before execution",
        }
    ]


def _continuation_requirements(continuation_status: dict[str, Any]) -> list[dict[str, Any]]:
    if continuation_status.get("status") != "revalidation_required":
        return []
    return [
        {
            "requirement": "continuation_revalidation",
            "rationale": "continuation requires runtime revalidation before execution",
        }
    ]


def _continuation_replay_obligations(continuation_status: dict[str, Any]) -> list[dict[str, Any]]:
    if continuation_status.get("status") != "escalation_required":
        return []
    return [
        {
            "obligation": "continuation_escalation",
            "rationale": "continuation requires escalation before execution",
        }
    ]


def _enforcement_consequences(
    *,
    status: str,
    violated_constraints: list[dict[str, Any]],
    required_evidence: list[dict[str, Any]],
    continuity_requirements: list[dict[str, Any]],
    replay_obligations: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    if status == "admissible":
        return [{"consequence": "allow_execution"}]
    if status == "blocked":
        return [
            {
                "consequence": "block_execution",
                "violated_constraints": violated_constraints,
                "required_evidence": required_evidence,
            }
        ]
    return [
        {
            "consequence": "escalate_execution",
            "continuity_requirements": continuity_requirements,
            "replay_obligations": replay_obligations,
        }
    ]


def _blocked_rationale(
    violated_constraints: list[dict[str, Any]],
    required_evidence: list[dict[str, Any]],
) -> str:
    if violated_constraints:
        return violated_constraints[0]["rationale"]
    if required_evidence:
        return required_evidence[0]["rationale"]
    return "execution is blocked"


def _approval_for_role(approvals: list[dict[str, Any]], role: str | None) -> dict[str, Any] | None:
    for approval in approvals:
        if approval.get("role") == role and approval.get("approved_by"):
            return approval
    return None


def _execution_amount(execution_request: dict[str, Any]) -> Any:
    arguments = execution_request.get("arguments")
    if isinstance(arguments, dict):
        return arguments.get("amount")
    return execution_request.get("amount")


def _condition_applies(condition: dict[str, Any] | None, amount: Any) -> bool:
    if not condition:
        return True
    if condition.get("field") != "amount":
        return False
    if amount is None:
        return True
    operator = condition.get("operator")
    value = condition.get("value")
    if operator == ">":
        return amount > value
    if operator == ">=":
        return amount >= value
    if operator == "<":
        return amount < value
    if operator == "<=":
        return amount <= value
    if operator == "==":
        return amount == value
    return False
