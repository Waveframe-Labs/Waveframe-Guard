"""Semantic summary derivation namespace."""
