"""Semantic summary derivation namespace."""
